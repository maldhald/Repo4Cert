# Setup Guide — Install & Import This Dataset

This walks through getting `nutrition.db` open and queryable on your own
machine, plus how to rebuild it from raw CSVs if needed. Pick the path
that matches your tool.

---

## Option A: Just open the database (most people want this)

You already have a built, populated database file: `data/nutrition.db`.
You do **not** need to "import" anything — SQLite databases are single
files. Opening the file IS having the database.

### A1. Using Python (works everywhere, no install needed)

Python ships with SQLite support built in — nothing to install.

1. Make sure you have Python 3 installed (`python3 --version` in a terminal).
2. From the folder containing `nutrition.db`, run:

```python
import sqlite3

conn = sqlite3.connect("nutrition.db")
cur = conn.cursor()

cur.execute("SELECT COUNT(*) FROM foods")
print("Total foods:", cur.fetchone()[0])

cur.execute("SELECT description FROM foods LIMIT 5")
for row in cur.fetchall():
    print(row)

conn.close()
```

3. If that prints food names, you're done — the database works.

### A2. Using DB Browser for SQLite (GUI, good for non-coders on the team)

1. Download "DB Browser for SQLite" (free) from https://sqlitebrowser.org/
2. Install it like any normal app (Windows/Mac/Linux all supported).
3. Open the app → **File → Open Database** → select `data/nutrition.db`.
4. Click the **"Execute SQL"** tab → paste a query from
   `docs/schema_overview.md` → click the play/run button.

This is the easiest option if you just want to look around the data
without writing code.

### A3. Using the `sqlite3` command-line tool

Some systems have this pre-installed, some don't.

**Check if you have it:**
```
sqlite3 --version
```

**If "command not found":**
- Mac: `brew install sqlite3` (needs Homebrew: https://brew.sh)
- Ubuntu/Debian/WSL: `sudo apt install sqlite3`
- Windows: download the precompiled binary from
  https://www.sqlite.org/download.html (grab the `sqlite-tools-win32` zip),
  unzip it, and run `sqlite3.exe` from that folder

**Then:**
```
cd path/to/nutrition-dataset/data
sqlite3 nutrition.db
```
You'll get a `sqlite>` prompt. Try:
```sql
.tables
SELECT COUNT(*) FROM foods;
.quit
```

### A4. Using a Node.js backend

```
npm install better-sqlite3
```
```js
const Database = require('better-sqlite3');
const db = new Database('nutrition.db');
const rows = db.prepare('SELECT description FROM foods LIMIT 5').all();
console.log(rows);
```

---

## Option B: Rebuild the database from raw CSVs

Only needed if you want to **regenerate** `nutrition.db` — for example,
after swapping in the larger SR Legacy dataset, or after editing the
allergen/vegan rules in `build_database.py`.

### Prerequisites
- Python 3.7 or newer (no extra packages needed — the script only uses
  Python's built-in `csv` and `sqlite3` modules)

### Steps

1. **Unzip this package** if you haven't already, so you have the
   `nutrition-dataset/` folder with `scripts/`, `data/`, `schema.sql` etc.
   all in place relative to each other (the script assumes this layout).

2. **Open a terminal** and navigate into the `scripts` folder:
   ```
   cd nutrition-dataset/scripts
   ```

3. **Run the build script**, pointing `--input` at a folder of FDC CSVs
   (the included `data/raw_csv/` folder works as a default test run):
   ```
   python3 build_database.py --input ../data/raw_csv --output ../data/nutrition.db
   ```

4. You should see output like:
   ```
   Reading FDC CSVs from: ../data/raw_csv
     food_category: 28 rows
     nutrients: 477 rows
     food.csv total rows: 87990 | valid food rows kept: 469
     food_nutrients: 21426 rows
     food_allergens: 174 flags created across 469 foods
     vegan-classified foods: 323 / 469 marked vegan
   Database written to: ../data/nutrition.db
   ```
   If you see this, it worked — `nutrition.db` has been regenerated.

5. **To use a bigger dataset (recommended — see README.md):**
   - Download the SR Legacy CSV bundle from
     https://fdc.nal.usda.gov/download-datafiles
   - Unzip it somewhere
   - Re-run the same command, pointing `--input` at that unzipped folder
     instead:
     ```
     python3 build_database.py --input /path/to/sr_legacy_folder --output ../data/nutrition.db
     ```
   - No code changes needed — the script auto-detects the food data type.

### Troubleshooting

| Problem | Fix |
|---|---|
| `python3: command not found` | Install Python from https://python.org (check "Add to PATH" on Windows install) |
| `unable to open database file` | The `data/` folder doesn't exist yet — run `mkdir data` first, or just use `--output nutrition.db` to write into your current folder |
| `FileNotFoundError: food.csv` | Your `--input` path is wrong, or you unzipped the FDC bundle into a nested subfolder — check with `ls <path>` (Mac/Linux) or `dir <path>` (Windows) that `food.csv` is directly inside |
| Script runs but `foods` table is empty | You're pointing at a CSV bundle that isn't a supported FDC dataset, or the food.csv has no rows with `data_type` in (`foundation_food`, `sr_legacy_food`, `survey_fndds_food`) |

---

## Quick sanity check after either option

Run this query (Python, GUI, or CLI — wherever you opened the DB) to
confirm everything imported correctly:

```sql
SELECT
  (SELECT COUNT(*) FROM foods) AS food_count,
  (SELECT COUNT(*) FROM nutrients) AS nutrient_count,
  (SELECT COUNT(*) FROM food_nutrients) AS nutrient_value_count,
  (SELECT COUNT(*) FROM food_allergens) AS allergen_flag_count;
```

Expected (for the included Foundation Foods build): `469, 477, 21426, 174`.
If you rebuilt with SR Legacy, `food_count` and `nutrient_value_count`
will be much larger.
