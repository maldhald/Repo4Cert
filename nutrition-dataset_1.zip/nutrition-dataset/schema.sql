-- ============================================================================
-- schema.sql
-- Simplified nutrition database schema, derived from USDA FoodData Central.
-- See docs/README.md and docs/tagging_logic.md for full explanation.
-- ============================================================================

PRAGMA foreign_keys = ON;

-- Reference list of food categories (USDA's classification, e.g. "Dairy and
-- Egg Products", "Poultry Products"). Kept mainly for context/filtering.
CREATE TABLE food_category (
    id          INTEGER PRIMARY KEY,
    code        TEXT,
    description TEXT
);

-- Reference list of nutrients FDC tracks (Energy, Protein, Vitamin C, etc.)
-- and the unit each is measured in.
CREATE TABLE nutrients (
    id            INTEGER PRIMARY KEY,
    name          TEXT NOT NULL,
    unit_name     TEXT,
    nutrient_nbr  TEXT,
    rank          REAL
);

-- One row per food. `data_type` tells you which underlying FDC dataset the
-- food came from (foundation_food / sr_legacy_food / survey_fndds_food) --
-- useful if you mix datasets and want to know provenance / data quality.
--
-- is_vegan: 1 = classified vegan, 0 = classified non-vegan.
-- This is a RULE-BASED classification, not an official USDA field --
-- see docs/tagging_logic.md. Treat as a strong default, not ground truth.
CREATE TABLE foods (
    fdc_id            INTEGER PRIMARY KEY,
    description       TEXT NOT NULL,
    food_category_id  INTEGER,
    data_type         TEXT,
    publication_date  TEXT,
    is_vegan          INTEGER DEFAULT NULL,  -- 1 / 0, set during tagging step
    FOREIGN KEY (food_category_id) REFERENCES food_category(id)
);

-- The actual nutrition facts: one row per (food, nutrient) pair.
-- `amount` is per 100g of the food, matching FDC convention.
CREATE TABLE food_nutrients (
    id           INTEGER PRIMARY KEY,
    fdc_id       INTEGER NOT NULL,
    nutrient_id  INTEGER NOT NULL,
    amount       REAL,
    FOREIGN KEY (fdc_id) REFERENCES foods(fdc_id),
    FOREIGN KEY (nutrient_id) REFERENCES nutrients(id)
);

-- Reference list of the 9 major FDA-recognized allergens.
CREATE TABLE allergens (
    code          TEXT PRIMARY KEY,   -- e.g. 'peanut', 'tree_nut'
    display_name  TEXT NOT NULL       -- e.g. 'Peanut', 'Tree Nut'
);

-- Many-to-many: which foods are flagged for which allergens.
-- A food can have zero, one, or multiple allergen flags.
-- This is RULE-BASED (category + keyword matching), not lab-verified --
-- see docs/tagging_logic.md for exact rules and limitations.
CREATE TABLE food_allergens (
    fdc_id         INTEGER NOT NULL,
    allergen_code  TEXT NOT NULL,
    PRIMARY KEY (fdc_id, allergen_code),
    FOREIGN KEY (fdc_id) REFERENCES foods(fdc_id),
    FOREIGN KEY (allergen_code) REFERENCES allergens(code)
);

-- ---------------------------------------------------------------------------
-- Indexes for the lookups an app will actually do:
--   - "give me all nutrients for food X"
--   - "give me all foods containing nutrient Y above some amount"
--   - "give me all foods NOT flagged for allergen Z"
--   - "give me all vegan foods in category C"
-- ---------------------------------------------------------------------------
CREATE INDEX idx_food_nutrients_fdcid   ON food_nutrients(fdc_id);
CREATE INDEX idx_food_nutrients_nutid   ON food_nutrients(nutrient_id);
CREATE INDEX idx_foods_category         ON foods(food_category_id);
CREATE INDEX idx_foods_vegan            ON foods(is_vegan);
CREATE INDEX idx_food_allergens_fdcid   ON food_allergens(fdc_id);
CREATE INDEX idx_food_allergens_code    ON food_allergens(allergen_code);
