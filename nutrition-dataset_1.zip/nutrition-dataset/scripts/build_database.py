#!/usr/bin/env python3
"""
build_database.py
==================
Builds a single SQLite database (nutrition.db) from raw USDA FoodData
Central (FDC) CSV exports.

WHY THIS SCRIPT EXISTS
-----------------------
The raw FDC download is a 24-table relational dump designed for USDA's
internal lab workflow (samples, sub-samples, acquisitions, conversion
factors, etc). Most of that is irrelevant to a consumer nutrition app.
This script extracts only what's needed and adds two things FDC does
NOT provide out of the box:

  1. Allergen flags  (9 major FDA allergens)
  2. Vegan / non-vegan classification

Both are derived using rule-based logic (food category + keyword
matching on the food description) — see docs/tagging_logic.md for the
full rationale and the rule tables themselves.

SUPPORTED INPUT DATASETS
-------------------------
This script works on ANY FDC CSV bundle that follows the standard
schema (food.csv, food_nutrient.csv, nutrient.csv, food_category.csv):

  - Foundation Foods   (~469 foods,  lab-verified, data_type='foundation_food')
  - SR Legacy          (~7,800 foods, data_type='sr_legacy_food')
  - Survey (FNDDS)     (data_type='survey_fndds_food')

Just point --input at the extracted folder. The script auto-detects
which data_type(s) are present and imports all non-sample/non-internal
food rows it finds.

USAGE
-----
    python3 build_database.py --input /path/to/extracted_fdc_folder --output nutrition.db

OUTPUT
------
A single SQLite file with the schema defined in schema.sql, populated
and indexed, ready to hand to the application team.
"""

import argparse
import csv
import os
import sqlite3
import sys

# Data types in food.csv that represent genuine, citable foods.
# Everything else (sample_food, sub_sample_food, market_acquisition,
# agricultural_acquisition) is internal USDA lab-tracking data used to
# DERIVE the foundation_food values and is not meant to be queried
# directly by an application.
VALID_DATA_TYPES = {"foundation_food", "sr_legacy_food", "survey_fndds_food"}

# ---------------------------------------------------------------------------
# Allergen keyword + category rules
# ---------------------------------------------------------------------------
# Format: allergen_code -> (set of food_category descriptions that are
# STRONG signals, set of keywords to match in the food description)
# A food is flagged for an allergen if EITHER its category matches OR
# a keyword is found in its description (case-insensitive, whole word
# where sensible). See docs/tagging_logic.md for rationale.

ALLERGENS = {
    "milk": {
        "categories": {"Dairy and Egg Products"},
        "keywords": ["milk", "cheese", "butter", "cream", "yogurt", "yoghurt",
                     "whey", "casein", "ghee", "custard"],
        "exclude_keywords": ["coconut milk", "almond milk", "soy milk", "oat milk",
                              "cream of tartar", "buttercup", "butterfly", "butternut",
                              "peanut butter", "cocoa butter", "shea butter", "cashew butter",
                              "almond butter"],
    },
    "egg": {
        "categories": set(),  # Dairy and Egg Products is shared with milk; use keywords
        "keywords": ["egg", "albumen", "meringue", "mayonnaise"],
        "exclude_keywords": ["eggplant"],
    },
    "peanut": {
        "categories": set(),
        "keywords": ["peanut"],
        "exclude_keywords": [],
    },
    "tree_nut": {
        # Category "Nut and Seed Products" also includes seeds (sesame,
        # sunflower, chia, flax) which are NOT tree nuts, so we rely on
        # keyword matching for precision rather than the category alone.
        "categories": set(),
        "keywords": ["almond", "cashew", "walnut", "pecan", "pistachio", "hazelnut",
                     "macadamia", "brazil nut", "pine nut", "chestnut"],
        "exclude_keywords": ["water chestnut"],
    },
    "soy": {
        "categories": set(),
        "keywords": ["soy", "soya", "tofu", "edamame", "tempeh", "miso"],
        "exclude_keywords": [],
    },
    "wheat_gluten": {
        "categories": {"Baked Products", "Cereal Grains and Pasta", "Breakfast Cereals"},
        "keywords": ["wheat", "flour", "bread", "pasta", "barley", "rye",
                     "couscous", "bulgur", "semolina", "malt", "cracker", "noodle"],
        "exclude_keywords": ["rice flour", "corn flour", "buckwheat", "almond flour",
                              "coconut flour", "rice noodle"],
    },
    "fish": {
        # NOTE: category is intentionally NOT used here. "Finfish and
        # Shellfish Products" covers both fish and shellfish, so relying on
        # category alone would cross-contaminate the two tags. Keyword
        # matching on the specific species name is more precise.
        "categories": set(),
        "keywords": ["salmon", "tuna", "cod", "tilapia", "halibut", "trout",
                     "anchovy", "sardine", "mackerel", "bass", "catfish",
                     "pollock", "haddock", "herring", "snapper", "swordfish",
                     "flounder", "fish"],
        "exclude_keywords": ["shellfish"],
    },
    "shellfish": {
        # Same reasoning as above — keywords only, not category.
        "categories": set(),
        "keywords": ["shrimp", "crab", "lobster", "clam", "oyster", "mussel",
                     "scallop", "crawfish", "prawn", "shellfish", "squid",
                     "octopus", "calamari"],
        "exclude_keywords": [],
    },
    "sesame": {
        "categories": set(),
        "keywords": ["sesame", "tahini"],
        "exclude_keywords": [],
    },
}

# ---------------------------------------------------------------------------
# Vegan classification rules
# ---------------------------------------------------------------------------
# A food defaults to vegan UNLESS:
#   (a) its category is in NON_VEGAN_CATEGORIES, or
#   (b) its description matches a NON_VEGAN_KEYWORD
# even if (a) is true, EXCEPTION_KEYWORDS can override back to vegan
# (e.g. "Soup, vegetable broth" inside a category that's often meaty).

NON_VEGAN_CATEGORIES = {
    "Dairy and Egg Products",
    "Poultry Products",
    "Sausages and Luncheon Meats",
    "Pork Products",
    "Beef Products",
    "Finfish and Shellfish Products",
    "Lamb, Veal, and Game Products",
}

NON_VEGAN_KEYWORDS = [
    "milk", "cheese", "butter", "cream", "yogurt", "yoghurt", "egg", "honey",
    "gelatin", "whey", "casein", "lard", "tallow", "meat", "chicken", "beef",
    "pork", "bacon", "ham", "turkey", "fish", "shrimp", "crab", "lobster",
    "anchovy", "broth", "bone", "collagen", "shellac", "albumen",
]

VEGAN_EXCEPTION_KEYWORDS = [
    "coconut milk", "almond milk", "soy milk", "oat milk", "vegetable broth",
    "vegetable stock", "cocoa butter", "shea butter", "peanut butter",
    "almond butter", "cashew butter", "apple butter",
]


def contains_keyword(description, keywords):
    desc_lower = description.lower()
    return any(kw in desc_lower for kw in keywords)


def tag_allergens(fdc_id, description, category_name, cur):
    desc_lower = description.lower()
    flagged = []
    for code, rule in ALLERGENS.items():
        category_hit = category_name in rule["categories"]
        keyword_hit = contains_keyword(description, rule["keywords"])
        excluded = contains_keyword(description, rule.get("exclude_keywords", []))
        if (category_hit or keyword_hit) and not excluded:
            flagged.append(code)
    for code in flagged:
        cur.execute(
            "INSERT INTO food_allergens (fdc_id, allergen_code) VALUES (?, ?)",
            (fdc_id, code),
        )
    return flagged


def classify_vegan(description, category_name):
    if contains_keyword(description, VEGAN_EXCEPTION_KEYWORDS):
        return 1
    if category_name in NON_VEGAN_CATEGORIES:
        return 0
    if contains_keyword(description, NON_VEGAN_KEYWORDS):
        return 0
    return 1


def load_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def build(input_dir, output_path):
    if os.path.exists(output_path):
        os.remove(output_path)

    conn = sqlite3.connect(output_path)
    cur = conn.cursor()

    schema_path = os.path.join(os.path.dirname(__file__), "..", "schema.sql")
    with open(schema_path) as f:
        cur.executescript(f.read())

    print(f"Reading FDC CSVs from: {input_dir}")

    # --- food_category ---
    categories = load_csv(os.path.join(input_dir, "food_category.csv"))
    cat_id_to_name = {}
    cur.executemany(
        "INSERT INTO food_category (id, code, description) VALUES (?,?,?)",
        [(c["id"], c["code"], c["description"]) for c in categories],
    )
    for c in categories:
        cat_id_to_name[c["id"]] = c["description"]
    print(f"  food_category: {len(categories)} rows")

    # --- nutrients ---
    nutrients = load_csv(os.path.join(input_dir, "nutrient.csv"))
    cur.executemany(
        "INSERT INTO nutrients (id, name, unit_name, nutrient_nbr, rank) VALUES (?,?,?,?,?)",
        [(n["id"], n["name"], n["unit_name"], n["nutrient_nbr"], n["rank"] or None) for n in nutrients],
    )
    print(f"  nutrients: {len(nutrients)} rows")

    # --- foods (filtered to valid data types only) ---
    foods_raw = load_csv(os.path.join(input_dir, "food.csv"))
    valid_foods = [f for f in foods_raw if f["data_type"] in VALID_DATA_TYPES]
    print(f"  food.csv total rows: {len(foods_raw)} | valid food rows kept: {len(valid_foods)}")

    valid_fdc_ids = set()
    food_rows = []
    for f in valid_foods:
        cat_id = f["food_category_id"] or None
        cat_name = cat_id_to_name.get(cat_id, None)
        food_rows.append((f["fdc_id"], f["description"], cat_id, f["data_type"], f["publication_date"]))
        valid_fdc_ids.add(f["fdc_id"])

    cur.executemany(
        "INSERT INTO foods (fdc_id, description, food_category_id, data_type, publication_date) VALUES (?,?,?,?,?)",
        food_rows,
    )

    # --- food_nutrients (only for valid foods, only rows with an amount) ---
    fn_path = os.path.join(input_dir, "food_nutrient.csv")
    inserted = 0
    with open(fn_path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        batch = []
        for row in reader:
            if row["fdc_id"] in valid_fdc_ids and row["amount"]:
                batch.append((row["id"], row["fdc_id"], row["nutrient_id"], float(row["amount"])))
                if len(batch) >= 5000:
                    cur.executemany(
                        "INSERT INTO food_nutrients (id, fdc_id, nutrient_id, amount) VALUES (?,?,?,?)",
                        batch,
                    )
                    inserted += len(batch)
                    batch = []
        if batch:
            cur.executemany(
                "INSERT INTO food_nutrients (id, fdc_id, nutrient_id, amount) VALUES (?,?,?,?)",
                batch,
            )
            inserted += len(batch)
    print(f"  food_nutrients: {inserted} rows")

    # --- allergens reference table ---
    cur.executemany(
        "INSERT INTO allergens (code, display_name) VALUES (?, ?)",
        [
            ("milk", "Milk"),
            ("egg", "Egg"),
            ("peanut", "Peanut"),
            ("tree_nut", "Tree Nut"),
            ("soy", "Soy"),
            ("wheat_gluten", "Wheat / Gluten"),
            ("fish", "Fish"),
            ("shellfish", "Shellfish"),
            ("sesame", "Sesame"),
        ],
    )

    # --- allergen + vegan tagging ---
    allergen_count = 0
    vegan_count = 0
    for fdc_id, description, cat_id, data_type, pub_date in food_rows:
        cat_name = cat_id_to_name.get(cat_id, "")
        flagged = tag_allergens(fdc_id, description, cat_name, cur)
        allergen_count += len(flagged)
        is_vegan = classify_vegan(description, cat_name)
        vegan_count += is_vegan
        cur.execute("UPDATE foods SET is_vegan = ? WHERE fdc_id = ?", (is_vegan, fdc_id))

    print(f"  food_allergens: {allergen_count} flags created across {len(food_rows)} foods")
    print(f"  vegan-classified foods: {vegan_count} / {len(food_rows)} marked vegan")

    conn.commit()

    # --- sanity check ---
    cur.execute("SELECT COUNT(*) FROM foods")
    print(f"\nFinal foods table row count: {cur.fetchone()[0]}")
    cur.execute("SELECT COUNT(*) FROM food_nutrients")
    print(f"Final food_nutrients row count: {cur.fetchone()[0]}")

    conn.close()
    print(f"\nDatabase written to: {output_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Build nutrition.db from raw FDC CSV export")
    parser.add_argument("--input", required=True, help="Path to extracted FDC CSV folder")
    parser.add_argument("--output", default="nutrition.db", help="Output SQLite file path")
    args = parser.parse_args()

    if not os.path.isdir(args.input):
        print(f"ERROR: input folder not found: {args.input}", file=sys.stderr)
        sys.exit(1)

    build(args.input, args.output)
