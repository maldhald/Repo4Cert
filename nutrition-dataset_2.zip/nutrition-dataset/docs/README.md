# Nutrition Dataset Package

This package contains a ready-to-use SQLite nutrition database, the script
that built it, and documentation of the logic behind it — for the team
building the calorie/diet-plan/hydration agentic app.

## What's in this zip

```
nutrition-dataset/
├── data/
│   ├── nutrition.db              <- the database, ready to query (includes Indian dishes)
│   └── raw_csv/                  <- original USDA source files (for reference/audit)
├── schema.sql                    <- table definitions
├── scripts/
│   ├── build_database.py         <- regenerates nutrition.db from raw USDA CSVs
│   ├── indian_dishes_data.py     <- ~123 Indian dish definitions (synthetic, estimated)
│   └── add_indian_dishes.py      <- adds the Indian dishes into nutrition.db
└── docs/
    ├── README.md                          <- this file
    ├── SETUP.md                           <- step-by-step install/import instructions
    ├── schema_overview.md                 <- table-by-table explanation + example queries
    ├── tagging_logic.md                   <- how allergen & vegan flags are determined
    └── synthetic_data_indian_dishes.md    <- methodology + disclaimer for the Indian dish data
```

## First time opening this? Start with `docs/SETUP.md`

It walks through installing whatever tool you want to use (Python, DB
Browser GUI, sqlite3 CLI, or Node) and opening `nutrition.db`, step by
step, with copy-pasteable commands and a troubleshooting table.

## Indian cuisine data — read this before using it

`nutrition.db` already includes 123 Indian dishes (Punjabi, South Indian,
Bengali, Gujarati, Maharashtrian, Rajasthani, and more) — already built
in, no extra step needed. **These are synthetic / estimated values, not
USDA lab data** — see `docs/synthetic_data_indian_dishes.md` for exactly
how they were generated, their limitations, and how to tell them apart
from real data in a query (`fdc_id < 0`, or `data_type = 'synthetic_estimated'`).

## Quick start for the team

You don't need to run anything — `data/nutrition.db` is ready to open right
now with any SQLite client, or via your language's SQLite driver:

```python
import sqlite3
conn = sqlite3.connect("nutrition.db")
cur = conn.cursor()
cur.execute("""
    SELECT f.description, n.name, fn.amount, n.unit_name
    FROM foods f
    JOIN food_nutrients fn ON f.fdc_id = fn.fdc_id
    JOIN nutrients n ON fn.nutrient_id = n.id
    WHERE f.description LIKE '%chicken breast%'
""")
for row in cur.fetchall():
    print(row)
```

```js
// Node, using better-sqlite3
const Database = require('better-sqlite3');
const db = new Database('nutrition.db');
const rows = db.prepare(`
    SELECT f.description, n.name, fn.amount, n.unit_name
    FROM foods f
    JOIN food_nutrients fn ON f.fdc_id = fn.fdc_id
    JOIN nutrients n ON fn.nutrient_id = n.id
    WHERE f.is_vegan = 1
    LIMIT 20
`).all();
```

## Source data — IMPORTANT, read before extending this

This database was built from USDA **FoodData Central — Foundation Foods**
dataset (469 foods). This is the dataset that was on hand while putting
this package together, and it's enough to build and test the full
pipeline end-to-end (schema, import script, allergen/vegan tagging).

**However, 469 foods is too small for a real diet-plan app** — you'll run
out of variety almost immediately. The recommended dataset for the actual
app is USDA's **SR Legacy** (~7,800 generic foods), or Foundation + SR
Legacy combined.

To upgrade:
1. Download the SR Legacy CSV bundle from
   https://fdc.nal.usda.gov/download-datafiles
2. Unzip it
3. Re-run: `python3 scripts/build_database.py --input <path_to_sr_legacy_folder> --output nutrition.db`

The script works unmodified on SR Legacy and FNDDS Survey data — it
auto-detects which FDC data type the rows belong to. No schema changes
needed.

## Data scope — what's deliberately excluded

The raw FDC download contains 24 tables, most of which are internal USDA
lab-tracking data (sample acquisitions, sub-samples, lab methods, etc.)
used to *derive* the published nutrient values — not separate foods. This
package keeps only the food + nutrient data an application actually needs.
See `docs/schema_overview.md` for the full breakdown.

## Known limitations (be upfront with whoever grades/reviews this)

- Allergen and vegan flags are **rule-based** (food category + keyword
  matching on the food name), not sourced from USDA directly — FDC does
  not provide allergen or vegan fields. See `docs/tagging_logic.md` for
  exact rules, and don't present these as medically certified allergen
  data in any user-facing copy. Recommend the app team add a disclaimer
  like "always verify against the product label."
- Nutrient `amount` values are **per 100g** of the food (USDA convention).
  Any serving-size conversion needs to happen in the app logic layer.
