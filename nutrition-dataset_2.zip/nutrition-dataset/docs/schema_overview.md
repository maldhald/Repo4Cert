# Schema Overview

5 tables. All food/nutrient values trace back to USDA FoodData Central;
`is_vegan` and the `food_allergens` table are added by this project's
build script (see `tagging_logic.md`).

## Tables

### `foods`
One row per food.

| Column | Type | Notes |
|---|---|---|
| fdc_id | INTEGER (PK) | USDA's permanent ID for this food — use this as the foreign key everywhere |
| description | TEXT | e.g. "Chicken, broilers or fryers, breast, meat only, cooked, roasted" |
| food_category_id | INTEGER | FK to `food_category` |
| data_type | TEXT | which dataset this came from: `foundation_food`, `sr_legacy_food`, `survey_fndds_food` (real USDA data), or `synthetic_estimated` (Indian dishes added separately — see synthetic_data_indian_dishes.md) |
| publication_date | TEXT | when USDA published this entry |
| is_vegan | INTEGER | 1 = vegan, 0 = not vegan. Rule-based — see tagging_logic.md |

### `nutrients`
Reference list of nutrients FDC tracks (Energy, Protein, Vitamin C, Sodium, etc).

| Column | Type | Notes |
|---|---|---|
| id | INTEGER (PK) | |
| name | TEXT | e.g. "Protein", "Energy", "Vitamin C, total ascorbic acid" |
| unit_name | TEXT | e.g. "G", "KCAL", "MG", "UG" |
| nutrient_nbr | TEXT | USDA's internal nutrient number |
| rank | REAL | USDA's display order hint (lower = more "primary" nutrient) |

### `food_nutrients`
The actual nutrition facts. One row per (food, nutrient) pair.

| Column | Type | Notes |
|---|---|---|
| id | INTEGER (PK) | |
| fdc_id | INTEGER | FK to `foods` |
| nutrient_id | INTEGER | FK to `nutrients` |
| amount | REAL | **per 100g of the food** — USDA's standard convention |

This is the table you JOIN against `foods` and `nutrients` to build a full
nutrition label for any food.

### `allergens`
Fixed reference list of the 9 major FDA-recognized allergens. Doesn't
change — just lookup data.

| Column | Type | Notes |
|---|---|---|
| code | TEXT (PK) | `milk`, `egg`, `peanut`, `tree_nut`, `soy`, `wheat_gluten`, `fish`, `shellfish`, `sesame` |
| display_name | TEXT | human-readable label |

### `food_allergens`
Many-to-many: which foods are flagged for which allergens. A food can
have 0, 1, or several rows here.

| Column | Type | Notes |
|---|---|---|
| fdc_id | INTEGER | FK to `foods` |
| allergen_code | TEXT | FK to `allergens` |

### `food_category`
USDA's food classification (Dairy, Poultry, Vegetables, etc). Useful for
filtering/grouping in the app, and is one of the inputs to the
vegan/allergen tagging logic.

| Column | Type | Notes |
|---|---|---|
| id | INTEGER (PK) | |
| code | TEXT | USDA category code |
| description | TEXT | e.g. "Dairy and Egg Products" |

---

## Example queries the app team will likely need

**Full nutrition label for one food:**
```sql
SELECT n.name, fn.amount, n.unit_name
FROM food_nutrients fn
JOIN nutrients n ON fn.nutrient_id = n.id
WHERE fn.fdc_id = 319874
ORDER BY n.rank;
```

**Find vegan foods under a calorie threshold (nutrient_id for Energy may
vary — check `nutrients` table for "Energy" with unit KCAL):**
```sql
SELECT f.description, fn.amount AS kcal_per_100g
FROM foods f
JOIN food_nutrients fn ON f.fdc_id = fn.fdc_id
JOIN nutrients n ON fn.nutrient_id = n.id
WHERE f.is_vegan = 1
  AND n.name = 'Energy' AND n.unit_name = 'KCAL'
  AND fn.amount < 150
ORDER BY fn.amount;
```

**Exclude foods with a given allergy (e.g. peanut) from a candidate list:**
```sql
SELECT f.fdc_id, f.description
FROM foods f
WHERE f.fdc_id NOT IN (
    SELECT fdc_id FROM food_allergens WHERE allergen_code = 'peanut'
);
```

**Multiple allergies at once (e.g. peanut AND shellfish):**
```sql
SELECT f.fdc_id, f.description
FROM foods f
WHERE f.fdc_id NOT IN (
    SELECT fdc_id FROM food_allergens
    WHERE allergen_code IN ('peanut', 'shellfish')
);
```

**Browse by category:**
```sql
SELECT f.description
FROM foods f
JOIN food_category c ON f.food_category_id = c.id
WHERE c.description = 'Vegetables and Vegetable Products';
```

## A note on units for the calorie/macro logic

`food_nutrients.amount` is always **per 100 grams** of the food, regardless
of nutrient. If your app logic computes a meal plan in different serving
sizes, you'll need to scale: `amount * (serving_grams / 100)`.
