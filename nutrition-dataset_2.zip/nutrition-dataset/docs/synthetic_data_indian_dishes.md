# Synthetic Data Addition: Indian Cuisine Dishes

## What this is

USDA's FoodData Central is almost entirely Western/generic foods —
Indian dishes are barely represented (a handful of "curry" entries at
best). To support an Indian-food-aware version of the app, this
project adds **123 Indian dishes** as **synthetic data**: records that
were not lab-measured by USDA, but estimated using domain knowledge of
typical recipe composition for each dish.

This is a standard technique called **synthetic data augmentation** —
filling a gap in a real dataset with artificially generated records that
follow the same structure, so downstream code doesn't need to treat them
differently.

## How these values were estimated

Each dish's nutrition values (calories, protein, fat, carbs, fiber,
sodium — all per 100g, matching USDA's convention) were estimated based
on:
- typical ingredient ratios for that dish category (e.g. cream/ghee-based
  curries skew higher fat; lentil dals skew higher protein/fiber; fried
  snacks skew higher fat/calories; rice dishes skew higher carbs)
- cross-referencing publicly available nutrition information for similar
  dishes to keep estimates in a realistic range

**These are NOT lab-measured values.** Real recipes vary enormously by
household, region, and restaurant — oil quantity alone can swing a
curry's calorie count by 30%+. Treat every number here as a reasonable
midpoint estimate, not ground truth.

## How it's structured in the database

Run `scripts/add_indian_dishes.py` after `build_database.py` has already
created `nutrition.db` from real USDA data. It:

1. Inserts each dish into `foods` with a **negative `fdc_id`**
   (e.g. -1, -2, -3...) — guaranteed never to collide with a real USDA
   `fdc_id`, which are always positive. This means **you can tell synthetic
   from real data just by checking the sign of `fdc_id`**, without even
   needing to check `data_type`.
2. Sets `data_type = 'synthetic_estimated'` on those rows — the explicit,
   queryable flag for "this is not USDA lab data."
3. Inserts nutrient values into the *same* `food_nutrients` table real
   foods use, mapped to the *same* `nutrients` reference rows (e.g.
   "Energy" / KCAL, "Protein" / G) — so any query the app team already
   wrote against real foods works identically against these, no special-
   casing needed.
4. Inserts allergen flags into `food_allergens` — same as real data, but
   pre-assigned per dish (not re-derived by keyword matching, since these
   dishes don't have a USDA `food_category` to run that logic against).
5. Adds one new `food_category` row: **"Indian Cuisine (Synthetic)"** —
   so these dishes are filterable as a group if the app wants to show
   "Indian Cuisine" as its own menu section.

## Why this matters for the app team

- **`fdc_id < 0` is the universal marker.** Any app logic that wants to
  exclude synthetic data (e.g. for a feature that must only use verified
  nutrition data) can simply filter `WHERE fdc_id > 0`.
- **`data_type = 'synthetic_estimated'`** is the human-readable / UI-facing
  version of the same flag — use this if you want to show users a "(estimated)"
  badge next to these dishes.
- Recommend the app show a disclaimer wherever these dishes appear, e.g.
  *"Nutrition values for Indian dishes are estimated, not lab-verified."*

## Regional coverage

123 dishes spanning: Punjabi, South Indian (Tamil, Kerala, Karnataka,
Andhra, Hyderabadi), Bengali, Gujarati, Maharashtrian, Rajasthani,
Mughlai/Lucknowi (Awadhi), Bihari, Northeast Indian, and Pan-Indian
street food/sweets/beverages — covering curries, dals, rice dishes,
breads, tandoori items, snacks, sweets, and beverages.

Vegan/vegetarian/non-vegetarian breakdown (of the 123):
- ~60 vegan
- ~39 vegetarian (contains dairy/ghee but no meat/fish/egg)
- ~24 non-vegetarian

## How to extend or edit

All dish data lives in `scripts/indian_dishes_data.py` as a plain Python
list of dicts — no database knowledge needed to edit it. To add a dish,
copy an existing entry's structure:

```python
{"name": "Dish Name", "region": "Region", "category": "curry",
 "veg": True, "vegan": False, "allergens": ["milk"],
 "nutrients": {"kcal": 150, "protein_g": 5.0, "fat_g": 8.0,
               "carb_g": 12.0, "fiber_g": 2.0, "sodium_mg": 300}},
```

Then re-run:
```
python3 scripts/add_indian_dishes.py --db data/nutrition.db
```

This is **safe to re-run anytime** — it removes any previously-added
synthetic rows first (matched by `data_type = 'synthetic_estimated'`)
before re-inserting, so you'll never get duplicates no matter how many
times you run it.

## Limitations — be upfront about these

- Nutrient values are estimates, not measurements. They are internally
  consistent (e.g. fried snacks > curries > dals > lean rice dishes, in
  calorie density) but individual numbers could be off by 15-30% from
  any specific real-world preparation.
- Only 6 nutrients are estimated per dish (calories, protein, fat, carbs,
  fiber, sodium) — far fewer than the 477 nutrients USDA tracks for real
  foods. Micronutrients (vitamins, specific minerals) are not included
  for these dishes.
- Allergen tags are assigned by the dish's known typical recipe, not
  derived from an ingredient list — same caveats as the rule-based
  tagging used for real USDA foods (see `tagging_logic.md`): not
  medically certified, doesn't account for recipe variation or
  cross-contamination.
- "Vegan" here follows the same definition as the rest of the dataset:
  no meat, fish, egg, dairy, or honey. Some dishes traditionally made
  with ghee can be made vegan with oil substitution — this dataset
  reflects the *traditional* preparation, not all possible variants.
