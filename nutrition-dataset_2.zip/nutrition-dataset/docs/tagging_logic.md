# Allergen & Vegan Tagging Logic

USDA FoodData Central does **not** provide allergen flags or vegan
classification — it only gives food names, categories, and nutrient
values. So both are derived here using rules, applied in
`scripts/build_database.py`. This doc explains exactly how, so the app
team understands what they're working with (and so whoever's grading
this can see the reasoning, not just the output).

## Why rule-based, and not something fancier

The alternative would be parsing ingredient lists from USDA's *Branded
Foods* dataset (it has real ingredient text, ~300k products). We're not
using that dataset here — the foods in scope (Foundation Foods / SR
Legacy) are **generic, single foods** like "Almonds, raw" or "Milk,
whole, 3.25% milkfat." For foods like this, the food's *name* already
tells you what it is — there's no hidden ingredient list to parse. So
category + keyword matching on the description is not a shortcut, it's
the appropriate method for this kind of data. Branded Foods would need a
different approach (actual ingredient parsing) — flag this if the team
ever expands into branded/packaged products.

## Allergen tagging

We tag for the 9 major FDA-recognized allergens: **milk, egg, peanut,
tree nut, soy, wheat/gluten, fish, shellfish, sesame**.

For each allergen, a food is flagged if:
- its USDA food category is a strong signal for that allergen, **or**
- its description contains a matching keyword

...**unless** it also matches an exclusion keyword (used for things like
"almond milk" not being a dairy product, or "eggplant" not containing
egg).

Example — milk:
```python
"milk": {
    "categories": {"Dairy and Egg Products"},
    "keywords": ["milk", "cheese", "butter", "cream", "yogurt", ...],
    "exclude_keywords": ["coconut milk", "almond milk", "soy milk", ...],
}
```

The full rule set for all 9 allergens lives in `scripts/build_database.py`
under `ALLERGENS` — that's the single source of truth; this doc explains
the *approach*, not a duplicate copy of the rules (so they can't drift
out of sync).

**Design choice worth knowing:** for fish and shellfish, we deliberately
do NOT use food category, even though USDA's category is literally called
"Finfish and Shellfish Products" — that category covers both, so using it
would tag every fish as also being a shellfish allergen risk (we hit this
bug during testing — "Anchovies" was getting flagged as both Fish and
Shellfish). We use only species-name keywords for these two.

## Vegan classification

Default: **vegan = true**, unless:
1. the food's category is one of the animal-product categories
   (Dairy and Egg Products, Poultry, Beef, Pork, Lamb/Veal/Game,
   Finfish and Shellfish, Sausages/Luncheon Meats), **or**
2. the description contains a non-vegan keyword (milk, cheese, egg,
   honey, gelatin, meat, fish, broth, etc.)

...**unless** an exception keyword overrides it back to vegan (e.g.
"vegetable broth", "almond milk", "peanut butter" — these match a
non-vegan keyword substring but are actually plant-based).

Full rule set: `NON_VEGAN_CATEGORIES`, `NON_VEGAN_KEYWORDS`, and
`VEGAN_EXCEPTION_KEYWORDS` in `scripts/build_database.py`.

## Limitations — read this before using these flags in user-facing copy

- **This is not medical or legally certified allergen data.** It's a
  best-effort classification for an app/demo context. If this becomes a
  real product, allergen flags would need to come from verified
  ingredient sourcing, not name-matching.
- **Cross-contamination risk is not modeled at all.** A food not flagged
  for peanut could still be produced in a facility that also processes
  peanuts. This dataset has no way to know that.
- **Keyword matching can miss uncommon names.** E.g. less common fish
  species or regional dish names not in our keyword lists won't get
  flagged. The keyword lists can be extended over time — they're plain
  Python lists/sets, easy to edit.
- **Vegan ≠ vegetarian.** This dataset only classifies vegan (no animal
  products including dairy/eggs/honey). If the app wants a separate
  vegetarian tier (dairy/egg OK, meat/fish not OK), that's a small
  addition to the same logic — ask and we can add a second column.
- Recommend showing users a disclaimer like *"Allergen and dietary tags
  are auto-generated and may not be complete — always check product
  labels."*

## How to extend the rules

Open `scripts/build_database.py`, find `ALLERGENS` or the vegan keyword
lists near the top of the file, add/remove keywords, then re-run:

```
python3 scripts/build_database.py --input <fdc_csv_folder> --output nutrition.db
```

The whole database rebuilds from scratch in a few seconds — there's no
need to hand-edit the `.db` file directly.

## Note on the Indian dishes dataset

The Indian cuisine dishes added via `add_indian_dishes.py` use a
*different* tagging approach — allergens are pre-assigned per dish
rather than derived by the rules above, since those dishes don't have
a USDA `food_category` to run keyword/category matching against. See
`docs/synthetic_data_indian_dishes.md` for that data's specific
methodology.
