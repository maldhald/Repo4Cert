#!/usr/bin/env python3
"""
add_indian_dishes.py
=====================
SYNTHETIC DATA ADDITION — adds ~120 Indian dishes to nutrition.db with
ESTIMATED (not lab-measured) nutrient values. Run this AFTER
build_database.py has already created nutrition.db from real USDA data.

WHAT THIS SCRIPT DOES
----------------------
1. Reads dish definitions from indian_dishes_data.py
2. Inserts each dish into `foods` with a NEGATIVE fdc_id
   (so they can never collide with a real USDA fdc_id, which are always
   positive) and data_type = 'synthetic_estimated'
3. Inserts their estimated nutrient values into `food_nutrients`,
   mapping to the SAME `nutrients` table USDA data uses (so app queries
   that join on nutrient name work identically for real and synthetic
   foods)
4. Inserts allergen flags into `food_allergens` (allergens are pre-set
   per dish in indian_dishes_data.py rather than re-derived by keyword
   matching, since these foods don't have a USDA food_category to base
   that logic on)
5. Adds a NEW food_category row: "Indian Cuisine (Synthetic)" so these
   dishes are clearly distinguishable and filterable in the foods table

WHY NEGATIVE fdc_id
--------------------
Real USDA fdc_id values are always positive integers. Using negative
IDs for synthetic entries guarantees zero collision risk, and lets
anyone instantly tell synthetic rows apart from real ones by checking
the sign — without needing to also check data_type.

USAGE
-----
    python3 add_indian_dishes.py --db ../data/nutrition.db

Safe to re-run: it deletes any previously-added synthetic rows first
(identified by data_type = 'synthetic_estimated') before re-inserting,
so running this twice does not create duplicates.
"""

import argparse
import sqlite3
import sys
from indian_dishes_data import DISHES

SYNTHETIC_CATEGORY_NAME = "Indian Cuisine (Synthetic)"
SYNTHETIC_CATEGORY_CODE = "9999"

# Map our nutrient keys to the `nutrients` table's existing entries.
# These names/units match how USDA's nutrient.csv names them, so the
# script reuses whatever nutrient_id already exists in the target DB
# rather than creating duplicate nutrient rows.
NUTRIENT_KEY_TO_NAME_UNIT = {
    "kcal":      ("Energy", "KCAL"),
    "protein_g": ("Protein", "G"),
    "fat_g":     ("Total lipid (fat)", "G"),
    "carb_g":    ("Carbohydrate, by difference", "G"),
    "fiber_g":   ("Fiber, total dietary", "G"),
    "sodium_mg": ("Sodium, Na", "MG"),
}


def get_or_create_category(cur):
    cur.execute("SELECT id FROM food_category WHERE description = ?", (SYNTHETIC_CATEGORY_NAME,))
    row = cur.fetchone()
    if row:
        return row[0]
    # Use a high id unlikely to collide with USDA's existing category ids (1-28 currently)
    new_id = 9999
    cur.execute(
        "INSERT INTO food_category (id, code, description) VALUES (?, ?, ?)",
        (new_id, SYNTHETIC_CATEGORY_CODE, SYNTHETIC_CATEGORY_NAME),
    )
    return new_id


def get_nutrient_id(cur, name, unit, cache):
    key = (name, unit)
    if key in cache:
        return cache[key]
    cur.execute("SELECT id FROM nutrients WHERE name = ? AND unit_name = ?", (name, unit))
    row = cur.fetchone()
    if row:
        cache[key] = row[0]
        return row[0]
    # Not found in this DB's nutrient table (shouldn't normally happen with
    # standard FDC data, but handle gracefully) — create it with a high id.
    cur.execute("SELECT MAX(id) FROM nutrients")
    max_id = cur.fetchone()[0] or 0
    new_id = max(max_id + 1, 90000)
    cur.execute(
        "INSERT INTO nutrients (id, name, unit_name, nutrient_nbr, rank) VALUES (?, ?, ?, NULL, NULL)",
        (new_id, name, unit),
    )
    cache[key] = new_id
    return new_id


def add_dishes(db_path):
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    cur.execute("PRAGMA foreign_keys = ON")

    # Clean re-run safety: remove any previously inserted synthetic rows
    cur.execute("SELECT fdc_id FROM foods WHERE data_type = 'synthetic_estimated'")
    existing_ids = [r[0] for r in cur.fetchall()]
    if existing_ids:
        print(f"Removing {len(existing_ids)} previously inserted synthetic dishes (clean re-run)...")
        cur.executemany("DELETE FROM food_nutrients WHERE fdc_id = ?", [(i,) for i in existing_ids])
        cur.executemany("DELETE FROM food_allergens WHERE fdc_id = ?", [(i,) for i in existing_ids])
        cur.executemany("DELETE FROM foods WHERE fdc_id = ?", [(i,) for i in existing_ids])

    category_id = get_or_create_category(cur)
    nutrient_cache = {}

    inserted_foods = 0
    inserted_nutrient_rows = 0
    inserted_allergen_rows = 0

    for i, dish in enumerate(DISHES, start=1):
        fdc_id = -i  # negative ID => guaranteed no collision with real USDA fdc_id

        cur.execute(
            """INSERT INTO foods (fdc_id, description, food_category_id, data_type, publication_date, is_vegan)
               VALUES (?, ?, ?, ?, NULL, ?)""",
            (fdc_id, dish["name"], category_id, "synthetic_estimated", 1 if dish["vegan"] else 0),
        )
        inserted_foods += 1

        for key, amount in dish["nutrients"].items():
            name, unit = NUTRIENT_KEY_TO_NAME_UNIT[key]
            nutrient_id = get_nutrient_id(cur, name, unit, nutrient_cache)
            # food_nutrients.id needs to be unique; use a negative composite
            # offset so it can't collide with real positive USDA ids either.
            fn_id = -(i * 100 + list(dish["nutrients"].keys()).index(key))
            cur.execute(
                "INSERT INTO food_nutrients (id, fdc_id, nutrient_id, amount) VALUES (?, ?, ?, ?)",
                (fn_id, fdc_id, nutrient_id, amount),
            )
            inserted_nutrient_rows += 1

        for allergen_code in dish["allergens"]:
            cur.execute(
                "INSERT OR IGNORE INTO food_allergens (fdc_id, allergen_code) VALUES (?, ?)",
                (fdc_id, allergen_code),
            )
            inserted_allergen_rows += 1

    conn.commit()

    print(f"Inserted {inserted_foods} synthetic Indian dishes")
    print(f"Inserted {inserted_nutrient_rows} nutrient value rows")
    print(f"Inserted {inserted_allergen_rows} allergen flag rows")

    # Sanity check
    cur.execute("SELECT COUNT(*) FROM foods WHERE data_type = 'synthetic_estimated'")
    print(f"\nVerification — synthetic dishes now in foods table: {cur.fetchone()[0]}")
    cur.execute("""
        SELECT description, is_vegan FROM foods
        WHERE data_type = 'synthetic_estimated'
        ORDER BY RANDOM() LIMIT 5
    """)
    print("Sample rows:")
    for row in cur.fetchall():
        print(" ", row)

    conn.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Add synthetic Indian dishes to nutrition.db")
    parser.add_argument("--db", required=True, help="Path to nutrition.db")
    args = parser.parse_args()
    add_dishes(args.db)
